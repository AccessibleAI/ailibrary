import click


@click.group()
def main():
    pass

#
# @main.command("run")
# @click.argument("command")
# def run(command):
#     pass